<?= $mail_template?>
<?= $mail_signature?>
