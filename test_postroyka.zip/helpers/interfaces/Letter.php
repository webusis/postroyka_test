<?php
namespace helpers\interfaces;

interface Letter{
    /**
     * @return string
     */
    public function SignColor() : string;
}