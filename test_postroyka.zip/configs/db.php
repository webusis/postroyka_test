<?php

const DB_NAME = 'cnvl';
const DB_USER = 'tema';
const DB_PASS = 'tema';
const DB_HOST = 'localhost';